<?php
// Check if form is submitted and the number is provided
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['number'])) {
    $number = $_POST['number'];
    echo "<!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Brainwave Analyzer</title>
        <style>
            body {
                font-family: 'Arial', sans-serif;
                background-color: #f4f4f9;
                text-align: center;
                padding-top: 50px;
            }
            h1 {
                color: #333;
            }
            .output-message {
                font-size: 1.5rem;
                color: #555;
                margin: 20px;
                opacity: 0;
                transition: opacity 2s ease-in-out;
            }
            .result {
                font-size: 2rem;
                font-weight: bold;
                color: #007bff;
            }
            .fade-in {
                opacity: 1 !important;
            }
        </style>
    </head>
    <body>
        <h1>Brainwave Analyzer</h1>
        <div class='output-message' id='message'></div>
        
        <!-- Audio files -->
        <audio id='analyzingSound' src='analyzing-brainwaves.mp3'></audio>
        <audio id='scanningSound' src='scanning-memories.mp3'></audio>
        <audio id='calculatingSound' src='calculating-probabilities.mp3'></audio>
        <audio id='decodingSound' src='decoding-thoughts.mp3'></audio>
        <audio id='resultSound' src='reveal-number.mp3'></audio>

        <script>
            function fadeInMessage(content, delay, soundId) {
                setTimeout(function() {
                    const messageDiv = document.getElementById('message');
                    messageDiv.innerHTML = content;
                    messageDiv.classList.add('fade-in');

                    // Play the sound
                    // sound effects from https://mixkit.co/free-sound-effects/static/ and converted to mp3s at https://www.freeconvert.com/wav-to-mp3
                    if (soundId) {
                        document.getElementById(soundId).play();
                    }
                }, delay);
            }

            fadeInMessage('<div>Analyzing Brainwaves...</div>', 1000, 'analyzingSound');
            fadeInMessage('<div>Scanning memories...</div>', 3000, 'scanningSound');
            fadeInMessage('<div>Calculating probabilities...</div>', 5000, 'calculatingSound');
            fadeInMessage('<div>Decoding thoughts...</div>', 7000, 'decodingSound');
            fadeInMessage('<div class=\"result\">You\'re thinking of the number $number!</div>', 9000, 'resultSound');
        </script>
    </body>
    </html>";
} else {
?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Brainwave Analyzer</title>
        <style>
            body {
                font-family: 'Arial', sans-serif;
                background-color: #f4f4f9;
                text-align: center;
                padding-top: 50px;
            }
            h1 {
                color: #333;
            }
            form {
                background-color: #fff;
                padding: 30px;
                box-shadow: 0 4px 10px rgba(0,0,0,0.1);
                display: inline-block;
                border-radius: 10px;
            }
            label {
                font-size: 1.2rem;
                color: #333;
            }
            input[type="number"] {
                width: 200px;
                padding: 10px;
                margin-top: 10px;
                font-size: 1rem;
                border: 1px solid #ddd;
                border-radius: 5px;
                margin-bottom: 20px;
            }
            button {
                padding: 10px 20px;
                background-color: #007bff;
                color: white;
                border: none;
                border-radius: 5px;
                font-size: 1rem;
                cursor: pointer;
            }
            button:hover {
                background-color: #0056b3;
            }
            .footer {
                margin-top: 50px;
                color: #aaa;
                font-size: 0.9rem;
            }
        </style>
    </head>
    <body>
        <h1>Brainwave Analyzer</h1>
        <form method="POST">
            <label for="number">Enter a number:</label><br>
            <input type="number" id="number" name="number" required><br>
            <button type="submit">Submit</button>
        </form>
        <div class="footer">A fun mind reading number guessing game!</div>
    </body>
    </html>
<?php
}
