<?php
// Simple CLI prompt function to get input from the user
function prompt($message) {
    echo $message;
    return trim(fgets(STDIN));
}

// Main function
function brainwaveAnalysis() {
    // Prompt user for input
    $number = prompt("Please enter a number: ");

    // Simulating the various processes
    echo "Analyzing Brainwaves..." . PHP_EOL;
    sleep(2); // Pause for 2 seconds
    
    echo "Scanning memories..." . PHP_EOL;
    sleep(2); // Pause for 2 seconds
    
    echo "Calculating probabilities..." . PHP_EOL;
    sleep(2); // Pause for 2 seconds
    
    echo "Decoding thoughts..." . PHP_EOL;
    sleep(2); // Pause for 2 seconds

    // Final output
    echo "You're thinking of the number $number!" . PHP_EOL;
}

// Run the brainwave analysis
brainwaveAnalysis();
