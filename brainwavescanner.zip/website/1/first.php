<?php
// Check if form is submitted and the number is provided
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['number'])) {
    $number = $_POST['number'];
    echo "<h3>Analyzing Brainwaves...</h3>";
    echo "<script>
            setTimeout(function() {
                document.body.innerHTML += '<h3>Scanning memories...</h3>';
            }, 2000);
            setTimeout(function() {
                document.body.innerHTML += '<h3>Calculating probabilities...</h3>';
            }, 4000);
            setTimeout(function() {
                document.body.innerHTML += '<h3>Decoding thoughts...</h3>';
            }, 6000);
            setTimeout(function() {
                document.body.innerHTML += '<h2>You\'re thinking of the number $number!</h2>';
            }, 8000);
          </script>";
} else {
?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Brainwave Analyzer</title>
    </head>
    <body>
        <h1>Brainwave Analyzer</h1>
        <form method="POST">
            <label for="number">Enter a number:</label>
            <input type="number" id="number" name="number" required>
            <button type="submit">Submit</button>
        </form>
    </body>
    </html>
<?php
}
